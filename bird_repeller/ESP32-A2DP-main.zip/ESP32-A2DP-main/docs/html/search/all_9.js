var searchData=
[
  ['log_5ffree_5fheap_0',['log_free_heap',['../class_bluetooth_a2_d_p_common.html#a791432e5c800e75fb11b858071cff651',1,'BluetoothA2DPCommon']]]
];
